import React from 'react'
import { Card } from 'react-bootstrap';
export function SignupPage() {
  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <Card className="p-4" style={{ width: '300px' }}>
        <h1 className="text-center">Sign Up</h1>
        <p className="text-center text-muted">Join us!</p>

        {/* Add signup form here */}
      </Card>
    </div>
  );
}