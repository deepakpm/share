export default function Signupdesign() {
  return (
    <div
      style={{ flex: 1 }}
      className="d-flex  justify-content-center flex-column align-items-start"
    >
      <p className="heading">Order Now</p>

      <button className="skip-lag">Hungry!!</button>
    </div>
  );
}
