import React from "react";
import { Route, Routes } from "react-router-dom";
import Container from "react-bootstrap/Container";
import { LoginPage } from "./pages/Login";
import { SignupPage } from "./pages/Signin";

export default function App() {
  return (
    <div>
      <Container className="bg-container" fluid>
        <Routes>
          <Route path="/login" element={<LoginPage />}></Route>
          <Route path="/signup" element={<SignupPage />}></Route>
        </Routes>
      </Container>
    </div>
  );
}
